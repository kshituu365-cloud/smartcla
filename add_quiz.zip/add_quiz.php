<?php
session_start();
require 'db.php';

// Ensure only teacher can access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: login.php");
    exit;
}

// Fetch subjects for dropdown
$subjects = [];
$result = $conn->query("SELECT id, name FROM subjects ORDER BY name");
while ($row = $result->fetch_assoc()) {
    $subjects[] = $row;
}

// Handle quiz question submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject_id = $_POST['subject_id'];
    $question   = trim($_POST['question']);
    $option_a   = trim($_POST['option_a']);
    $option_b   = trim($_POST['option_b']);
    $option_c   = trim($_POST['option_c']);
    $option_d   = trim($_POST['option_d']);
    $correct    = $_POST['correct'];

    if (!empty($subject_id) && !empty($question) && !empty($option_a) && !empty($option_b) && !empty($option_c) && !empty($option_d) && !empty($correct)) {
        $stmt = $conn->prepare("INSERT INTO quizzes (subject_id, question, option_a, option_b, option_c, option_d, correct_option) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issssss", $subject_id, $question, $option_a, $option_b, $option_c, $option_d, $correct);

        if ($stmt->execute()) {
            $success = "Quiz question added successfully!";
        } else {
            $error = "Error: " . $conn->error;
        }
        $stmt->close();
    } else {
        $error = "All fields are required.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Add Quiz Question</title>
    <link rel="stylesheet" href="style.css">
</head>
<body style="background-image:url('https://wallpapercave.com/wp/wp2590353.jpg');background-size:2000px;">

    <?php include 'navbar.php'; ?>

    <div class="container">
        <h2>Add Quiz Question</h2>

        <?php if (!empty($success)) echo "<p class='success'>$success</p>"; ?>
        <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>

        <form method="post">
            <label for="subject_id">Select Subject:</label>
            <select name="subject_id" id="subject_id" required>
                <option value="">--Select--</option>
                <?php foreach ($subjects as $sub): ?>
                    <option value="<?= $sub['id'] ?>"><?= htmlspecialchars($sub['name']) ?></option>
                <?php endforeach; ?>
            </select>

            <label for="question">Question:</label>
            <textarea name="question" id="question" required></textarea>

            <label>Options:</label>
            <input type="text" name="option_a" placeholder="Option A" required>
            <input type="text" name="option_b" placeholder="Option B" required>
            <input type="text" name="option_c" placeholder="Option C" required>
            <input type="text" name="option_d" placeholder="Option D" required>

            <label for="correct">Correct Option:</label>
            <select name="correct" id="correct" required>
                <option value="">--Select--</option>
                <option value="A">Option A</option>
                <option value="B">Option B</option>
                <option value="C">Option C</option>
                <option value="D">Option D</option>
            </select>

            <button type="submit" class="btn">Add Question</button>
        </form>
    </div>
</body>
</html>
